# Neon Client (Fabric, Minecraft 1.21.11, client-side)

Premi **Right Shift** in gioco per aprire la GUI.

## Compilare
1. Installa JDK 21.
2. Controlla le versioni in `gradle.properties` su https://fabricmc.net/develop/ (loader e Fabric API per 1.21.11).
3. `gradle wrapper` (una volta sola, se non hai il wrapper), poi `./gradlew build`.
4. Il jar finale e' in `build/libs/neon-client-1.0.0.jar` (NON il `-sources`). Mettilo in `mods/` insieme a Fabric API.

## Struttura
- `NeonClient` - entrypoint, apertura GUI con Right Shift, tasti associati ai moduli
- `NeonConfig` - salva stile/colori/tasti/preferiti/velocita in `config/neonclient.json`
- `module/` - sistema moduli; `FreecamModule` e' l'unico modulo (categoria Render)
- `gui/NeonScreen` - GUI (Modules, Config, Customize, Macros, Profiles)
- `mixin/` - Camera (posizione/rotazione libere), Entity (mouse), Minecraft (blocca attacco/uso durante freecam)

## Aggiungere un modulo
Crea una classe che estende `Module`, registrala in `ModuleManager.init()`: compare da sola nella sua colonna.

## Compilare con GitHub (senza PC)
1. Crea un repository su github.com e carica tutto il contenuto di questa cartella (compresa `.github`).
2. Scheda **Actions** -> workflow "Build Neon Client" -> apri l'ultima esecuzione (verde).
3. In fondo, sezione **Artifacts**: scarica `neon-client-jar` (zip contenente il jar).

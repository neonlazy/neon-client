package dev.neonclient.gui;

import dev.neonclient.NeonConfig;
import dev.neonclient.NeonConfig.Style;
import dev.neonclient.module.Category;
import dev.neonclient.module.Module;
import dev.neonclient.module.ModuleManager;
import dev.neonclient.module.NumberSetting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Random;

/**
 * GUI di Neon Client. Disegno + input in "immediate mode": il mouse e la tastiera vengono
 * letti direttamente da GLFW a ogni frame, cosi' non dipende dalle firme (cambiate spesso)
 * dei metodi di input di Screen.
 */
public class NeonScreen extends Screen {
    private static final String[] TABS = {"Modules", "Config", "Customize", "Macros", "Profiles"};
    private static final Category[] COLUMNS = {
            Category.MOVEMENT, Category.COMBAT, Category.WORLD, Category.PLAYER,
            Category.RENDER, Category.MISC, Category.FAVORITES};
    private static final int[] PRESETS = {
            0x9B30FF, 0x00D4FF, 0xFF3CAC, 0x2BFF88, 0xFF3B3B, 0xFF9F1C, 0x3A86FF, 0xFFFFFF};

    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFFB0B0C0;
    private static final int PANEL = 0xF0141520;
    private static final int ROW = 13;

    private int tab = 0;
    private Module settingsModule;
    private boolean listening;
    private String dragId;

    private boolean prevL, prevR;
    private final boolean[] prevKeys = new boolean[GLFW.GLFW_KEY_LAST + 1];

    // costellazione
    private static final int N = 45;
    private float[] px, py, pvx, pvy;
    private int lastW, lastH;
    private long lastFrame;

    public NeonScreen() {
        super(Component.literal("Neon Client"));
        long win = GLFW.glfwGetCurrentContext();
        prevL = GLFW.glfwGetMouseButton(win, 0) == GLFW.GLFW_PRESS;
        prevR = GLFW.glfwGetMouseButton(win, 1) == GLFW.GLFW_PRESS;
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            prevKeys[k] = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return !listening;
    }

    @Override
    public void removed() {
        NeonConfig.save();
        super.removed();
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mx, int my, float partialTick) {
        long win = GLFW.glfwGetCurrentContext();
        boolean l = GLFW.glfwGetMouseButton(win, 0) == GLFW.GLFW_PRESS;
        boolean r = GLFW.glfwGetMouseButton(win, 1) == GLFW.GLFW_PRESS;
        boolean lp = l && !prevL;
        boolean rp = r && !prevR;
        boolean[] down = new boolean[prevKeys.length];
        for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
            down[k] = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
        }

        // associazione tasto
        if (listening && settingsModule != null) {
            for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
                if (down[k] && !prevKeys[k]) {
                    if (k == GLFW.GLFW_KEY_BACKSPACE || k == GLFW.GLFW_KEY_DELETE) settingsModule.key = 0;
                    else if (k != GLFW.GLFW_KEY_ESCAPE) settingsModule.key = k;
                    listening = false;
                    NeonConfig.save();
                    break;
                }
            }
        } else if (down[GLFW.GLFW_KEY_RIGHT_SHIFT] && !prevKeys[GLFW.GLFW_KEY_RIGHT_SHIFT]) {
            this.onClose();
            return;
        }

        boolean popupOpen = settingsModule != null;
        int w = this.width, h = this.height;

        drawBackground(g, w, h);
        drawTabs(g, w, mx, my, lp && !popupOpen);

        switch (tab) {
            case 0 -> drawModules(g, w, h, mx, my, lp && !popupOpen, rp && !popupOpen);
            case 2 -> drawCustomize(g, w, mx, my, lp && !popupOpen, l);
            default -> g.drawCenteredString(this.font, "Empty for now", w / 2, 60, GRAY);
        }

        if (popupOpen) drawPopup(g, w, h, mx, my, lp, l);

        if (!l) dragId = null;
        prevL = l;
        prevR = r;
        System.arraycopy(down, 0, prevKeys, 0, down.length);
    }

    // ------------------------------------------------------------------ background / theme

    private static int argb(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    private void headerFill(GuiGraphics g, int x, int y, int w, int h) {
        int c1 = argb(NeonConfig.color1(), 0xFF);
        if (NeonConfig.style() == Style.GRADIENT) {
            g.fillGradient(x, y, x + w, y + h, c1, argb(NeonConfig.color2(), 0xFF));
        } else {
            g.fill(x, y, x + w, y + h, c1);
        }
    }

    private void drawBackground(GuiGraphics g, int w, int h) {
        switch (NeonConfig.style()) {
            case SOLID -> g.fill(0, 0, w, h, 0x99000000);
            case GRADIENT -> {
                g.fill(0, 0, w, h, 0x70000000);
                g.fillGradient(0, 0, w, h, argb(NeonConfig.color1(), 0x55), argb(NeonConfig.color2(), 0x55));
            }
            case CONSTELLATION -> {
                g.fill(0, 0, w, h, 0xB4000000);
                drawConstellation(g, w, h);
            }
        }
    }

    private void drawConstellation(GuiGraphics g, int w, int h) {
        if (px == null || w != lastW || h != lastH) {
            Random rnd = new Random();
            px = new float[N]; py = new float[N]; pvx = new float[N]; pvy = new float[N];
            for (int i = 0; i < N; i++) {
                px[i] = rnd.nextFloat() * w;
                py[i] = rnd.nextFloat() * h;
                pvx[i] = (rnd.nextFloat() - 0.5f) * 24f;
                pvy[i] = (rnd.nextFloat() - 0.5f) * 24f;
            }
            lastW = w;
            lastH = h;
            lastFrame = 0;
        }
        long now = System.nanoTime();
        float dt = lastFrame == 0 ? 0f : Math.min((now - lastFrame) / 1_000_000_000f, 0.1f);
        lastFrame = now;

        int rgb = NeonConfig.color1();
        for (int i = 0; i < N; i++) {
            px[i] += pvx[i] * dt;
            py[i] += pvy[i] * dt;
            if (px[i] < 0 || px[i] > w) pvx[i] = -pvx[i];
            if (py[i] < 0 || py[i] > h) pvy[i] = -pvy[i];
            px[i] = Math.max(0, Math.min(w, px[i]));
            py[i] = Math.max(0, Math.min(h, py[i]));
        }
        final float maxD = 70f;
        for (int i = 0; i < N; i++) {
            for (int j = i + 1; j < N; j++) {
                float dx = px[j] - px[i], dy = py[j] - py[i];
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d >= maxD) continue;
                int a = (int) (0xA0 * (1f - d / maxD));
                int steps = Math.max(1, (int) (d / 2f));
                for (int s = 0; s <= steps; s++) {
                    int x = (int) (px[i] + dx * s / steps);
                    int y = (int) (py[i] + dy * s / steps);
                    g.fill(x, y, x + 1, y + 1, argb(rgb, a));
                }
            }
        }
        for (int i = 0; i < N; i++) {
            int x = (int) px[i], y = (int) py[i];
            g.fill(x - 1, y - 1, x + 2, y + 2, argb(rgb, 0xFF));
        }
    }

    // ------------------------------------------------------------------ tabs

    private void drawTabs(GuiGraphics g, int w, int mx, int my, boolean lp) {
        int total = 0;
        for (String t : TABS) total += this.font.width(t) + 14;
        int x = (w - total) / 2;
        g.fill(x, 2, x + total, 17, 0xE0161722);
        for (int i = 0; i < TABS.length; i++) {
            int tw = this.font.width(TABS[i]) + 14;
            boolean hover = in(mx, my, x, 2, tw, 15);
            if (i == tab) g.fill(x, 2, x + tw, 17, argb(NeonConfig.color1(), 0xFF));
            else if (hover) g.fill(x, 2, x + tw, 17, 0x33FFFFFF);
            g.drawCenteredString(this.font, TABS[i], x + tw / 2, 6, WHITE);
            if (hover && lp) tab = i;
            x += tw;
        }
    }

    // ------------------------------------------------------------------ modules tab

    private void drawModules(GuiGraphics g, int w, int h, int mx, int my, boolean lp, boolean rp) {
        int n = COLUMNS.length, gap = 4;
        int colW = Math.max(64, Math.min(112, (w - 8 - (n - 1) * gap) / n));
        int total = n * colW + (n - 1) * gap;
        int sx = (w - total) / 2, y0 = 26;

        for (int i = 0; i < n; i++) {
            Category c = COLUMNS[i];
            int x = sx + i * (colW + gap);
            headerFill(g, x, y0, colW, 16);
            g.drawCenteredString(this.font, c.label, x + colW / 2, y0 + 4, WHITE);

            List<Module> mods = ModuleManager.byCategory(c);
            if (mods.isEmpty()) continue;
            int ry = y0 + 16;
            g.fill(x, ry, x + colW, ry + ROW * mods.size(), 0xDD141520);
            for (int j = 0; j < mods.size(); j++) {
                Module m = mods.get(j);
                int rowY = ry + ROW * j;
                boolean hover = in(mx, my, x, rowY, colW, ROW);
                if (m.enabled) g.fill(x, rowY, x + colW, rowY + ROW, argb(NeonConfig.color1(), 0x90));
                else if (hover) g.fill(x, rowY, x + colW, rowY + ROW, 0x33FFFFFF);
                g.drawCenteredString(this.font, m.name, x + colW / 2, rowY + 3, m.enabled ? WHITE : 0xFFD0D0DA);
                if (hover && lp) m.toggle();
                if (hover && rp) {
                    settingsModule = m;
                    listening = false;
                }
            }
        }
        g.drawString(this.font, "Left click - Toggle module", 4, h - 22, WHITE);
        g.drawString(this.font, "Right click - Open module settings", 4, h - 11, WHITE);
    }

    // ------------------------------------------------------------------ module settings popup

    private void drawPopup(GuiGraphics g, int w, int h, int mx, int my, boolean lp, boolean l) {
        Module m = settingsModule;
        int pw = 200;
        int ph = 22 + m.settings.size() * 24 + 20 + 20 + 6;
        int x0 = (w - pw) / 2, y0 = (h - ph) / 2;

        g.fill(x0 - 1, y0 - 1, x0 + pw + 1, y0 + ph + 1, argb(NeonConfig.color1(), 0xFF));
        g.fill(x0, y0, x0 + pw, y0 + ph, PANEL);
        headerFill(g, x0, y0, pw, 16);
        g.drawCenteredString(this.font, m.name + " settings", x0 + pw / 2, y0 + 4, WHITE);

        int cy = y0 + 22;
        for (NumberSetting s : m.settings) {
            double v = slider(g, "set:" + s.name, x0 + 8, cy, pw - 16, s.name, s.min, s.max, s.value, 1, mx, my, lp, l);
            s.set(v);
            cy += 24;
        }

        String keyLabel = "Keybind: " + (listening ? "press a key..." : keyName(m.key));
        if (button(g, x0 + 8, cy, pw - 16, 14, keyLabel, listening, mx, my) && lp) listening = !listening;
        cy += 20;

        String favLabel = "Favorite: " + (m.favorite ? "ON" : "OFF");
        if (button(g, x0 + 8, cy, pw - 16, 14, favLabel, m.favorite, mx, my) && lp) {
            m.favorite = !m.favorite;
            NeonConfig.save();
        }

        if (lp && !in(mx, my, x0, y0, pw, ph)) {
            settingsModule = null;
            listening = false;
            NeonConfig.save();
        }
    }

    // ------------------------------------------------------------------ customize tab

    private void drawCustomize(GuiGraphics g, int w, int mx, int my, boolean lp, boolean l) {
        boolean grad = NeonConfig.style() == Style.GRADIENT;
        int pw = 260;
        int block = 96;
        int ph = 22 + 34 + block + (grad ? block : 0) + 6;
        int x0 = (w - pw) / 2, y0 = 26;

        g.fill(x0 - 1, y0 - 1, x0 + pw + 1, y0 + ph + 1, argb(NeonConfig.color1(), 0xFF));
        g.fill(x0, y0, x0 + pw, y0 + ph, PANEL);
        headerFill(g, x0, y0, pw, 16);
        g.drawCenteredString(this.font, "Customize", x0 + pw / 2, y0 + 4, WHITE);

        int cy = y0 + 22;
        g.drawString(this.font, "Style", x0 + 8, cy, GRAY);
        cy += 11;
        Style[] styles = Style.values();
        int bw = (pw - 16 - (styles.length - 1) * 4) / styles.length;
        for (int i = 0; i < styles.length; i++) {
            int bx = x0 + 8 + i * (bw + 4);
            boolean sel = NeonConfig.style() == styles[i];
            if (button(g, bx, cy, bw, 14, styles[i].label, sel, mx, my) && lp) {
                NeonConfig.setStyle(styles[i]);
            }
        }
        cy += 23;

        NeonConfig.setColor1(colorEditor(g, x0 + 8, cy, pw - 16, "c1", grad ? "Color 1" : "Color", NeonConfig.color1(), mx, my, lp, l));
        cy += block;
        if (grad) {
            NeonConfig.setColor2(colorEditor(g, x0 + 8, cy, pw - 16, "c2", "Color 2", NeonConfig.color2(), mx, my, lp, l));
        }
    }

    private int colorEditor(GuiGraphics g, int x, int y, int w, String id, String label, int rgb,
                            int mx, int my, boolean lp, boolean l) {
        g.drawString(this.font, label, x, y, GRAY);
        g.fill(x + w - 20, y - 1, x + w, y + 9, argb(rgb, 0xFF));

        for (int i = 0; i < PRESETS.length; i++) {
            int sx = x + i * 17;
            g.fill(sx - 1, y + 11, sx + 15, y + 25, 0xFF000000);
            g.fill(sx, y + 12, sx + 14, y + 24, argb(PRESETS[i], 0xFF));
            if (lp && in(mx, my, sx, y + 12, 14, 12)) rgb = PRESETS[i];
        }

        int r = (rgb >> 16) & 0xFF, gr = (rgb >> 8) & 0xFF, b = rgb & 0xFF;
        r = (int) Math.round(slider(g, id + "r", x, y + 28, w, "R", 0, 255, r, 1, mx, my, lp, l));
        gr = (int) Math.round(slider(g, id + "g", x, y + 50, w, "G", 0, 255, gr, 1, mx, my, lp, l));
        b = (int) Math.round(slider(g, id + "b", x, y + 72, w, "B", 0, 255, b, 1, mx, my, lp, l));
        return (r << 16) | (gr << 8) | b;
    }

    // ------------------------------------------------------------------ widgets

    private double slider(GuiGraphics g, String id, int x, int y, int w, String label,
                          double min, double max, double value, double step,
                          int mx, int my, boolean lp, boolean l) {
        boolean hover = in(mx, my, x, y + 9, w, 11);
        if (lp && hover) dragId = id;
        if (l && id.equals(dragId)) {
            double t = Math.max(0, Math.min(1, (mx - x) / (double) w));
            value = min + t * (max - min);
            if (step > 0) value = Math.round(value / step) * step;
        }
        double t = (value - min) / (max - min);
        String txt = (max - min > 100 || step >= 1) ? String.valueOf((int) Math.round(value))
                : String.format("%.1f", value);
        g.drawString(this.font, label + ": " + txt, x, y, WHITE);
        g.fill(x, y + 12, x + w, y + 17, 0xFF2A2B3A);
        int fw = (int) (w * t);
        g.fill(x, y + 12, x + fw, y + 17, argb(NeonConfig.color1(), 0xFF));
        g.fill(x + fw - 1, y + 10, x + fw + 2, y + 19, WHITE);
        return Math.max(min, Math.min(max, value));
    }

    /** Disegna un bottone e restituisce true se il mouse e' sopra (il click lo gestisce il chiamante). */
    private boolean button(GuiGraphics g, int x, int y, int w, int h, String label, boolean active, int mx, int my) {
        boolean hover = in(mx, my, x, y, w, h);
        int bg = active ? argb(NeonConfig.color1(), 0xC0) : (hover ? 0xFF2F3045 : 0xFF22232F);
        g.fill(x, y, x + w, y + h, bg);
        g.drawCenteredString(this.font, label, x + w / 2, y + (h - 8) / 2, WHITE);
        return hover;
    }

    private static boolean in(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private static String keyName(int code) {
        if (code <= 0) return "None";
        switch (code) {
            case GLFW.GLFW_KEY_SPACE: return "Space";
            case GLFW.GLFW_KEY_LEFT_SHIFT: return "L-Shift";
            case GLFW.GLFW_KEY_RIGHT_SHIFT: return "R-Shift";
            case GLFW.GLFW_KEY_LEFT_CONTROL: return "L-Ctrl";
            case GLFW.GLFW_KEY_RIGHT_CONTROL: return "R-Ctrl";
            case GLFW.GLFW_KEY_LEFT_ALT: return "L-Alt";
            case GLFW.GLFW_KEY_RIGHT_ALT: return "R-Alt";
            case GLFW.GLFW_KEY_TAB: return "Tab";
            case GLFW.GLFW_KEY_ENTER: return "Enter";
            case GLFW.GLFW_KEY_UP: return "Up";
            case GLFW.GLFW_KEY_DOWN: return "Down";
            case GLFW.GLFW_KEY_LEFT: return "Left";
            case GLFW.GLFW_KEY_RIGHT: return "Right";
            case GLFW.GLFW_KEY_CAPS_LOCK: return "Caps Lock";
            case GLFW.GLFW_KEY_INSERT: return "Insert";
            case GLFW.GLFW_KEY_HOME: return "Home";
            case GLFW.GLFW_KEY_END: return "End";
            case GLFW.GLFW_KEY_PAGE_UP: return "Page Up";
            case GLFW.GLFW_KEY_PAGE_DOWN: return "Page Down";
            default: break;
        }
        if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F25) return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
        String n = GLFW.glfwGetKeyName(code, 0);
        return n != null ? n.toUpperCase() : "Key " + code;
    }
}
